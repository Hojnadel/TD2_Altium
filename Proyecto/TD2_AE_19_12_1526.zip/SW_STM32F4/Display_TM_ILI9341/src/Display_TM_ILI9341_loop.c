/*
 * Display_TM_ILI9341_loop.c
 *
 *  Created on: 9 mar. 2018
 *      Author: alumno
 */










/********************************************************************
 *						INCLUDES
 ********************************************************************/
	#include "Display_TM_ILI9341.h"

	#include "header.h"

	#include "FreeRTOS.h"

	#include "cmsis_os.h"

#include "stdlib.h"









/********************************************************************
 *						FUNCIONES									*
 ********************************************************************/



	extern	float32_t transformada_final[MUESTRAS/2];

	extern	float32_t transformada_final_anterior[MUESTRAS/2];

//	extern  uint16_t posicion_ventana;
//
//	extern uint16_t tipo_ventana;
	extern osMessageQId QueueWindowHandle;
	extern osMessageQId QueueSpanHandle;


	void TM_ILI9341_Welcome_Screen(void)
	{
		//TM_ILI9341_Orientation peperota=TM_ILI9341_Landscape ;
			/* MODOS DE ORIENTACION (funcion TM_ILI9341_Rotate())
			 * 0: MAL
			 * 1: MAL
			 * 2: Vertical con pines arriba
			 * 3: Vertical con pines abajo
			 * 4: Apaisado con pines hacia la izquierda
			 * 5: Apaisado con pines hacia la derecha
			 */

		TM_ILI9341_Rotate(TM_ILI9341_Orientation_Landscape_2);
		TM_ILI9341_Fill(ILI9341_COLOR_BLACK);

		TM_ILI9341_Puts(10, 10, "UTN-FRBA                2018", &TM_Font_11x18, ILI9341_COLOR_BLUE, ILI9341_COLOR_BLACK);

		TM_ILI9341_DrawFilledCircle(20, 50, 10, ILI9341_COLOR_YELLOW);
		TM_ILI9341_DrawFilledCircle(60, 50, 10, ILI9341_COLOR_WHITE);
		TM_ILI9341_DrawFilledCircle(100, 50, 10, ILI9341_COLOR_RED);
		TM_ILI9341_DrawFilledCircle(140, 50, 10, ILI9341_COLOR_GREEN);
		TM_ILI9341_DrawFilledCircle(180, 50, 10, ILI9341_COLOR_BLUE);
		TM_ILI9341_DrawFilledCircle(220, 50, 10, ILI9341_COLOR_MAGENTA);
		TM_ILI9341_DrawFilledCircle(260, 50, 10, ILI9341_COLOR_GRAY);
		TM_ILI9341_DrawFilledCircle(300, 50, 10, ILI9341_COLOR_BROWN);

		TM_ILI9341_Puts(75, 85, "Analizador", &TM_Font_16x26, ILI9341_COLOR_CYAN, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts(75, 115, "de Fourier", &TM_Font_16x26, ILI9341_COLOR_CYAN, ILI9341_COLOR_BLACK);

		TM_ILI9341_Puts(80, 145, "Tecnicas", &TM_Font_16x26, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts(67, 175, "Digitales II", &TM_Font_16x26, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);

		TM_ILI9341_Puts(110, 215, "Aprobame!", &TM_Font_11x18, ILI9341_COLOR_MY_VIOLET, ILI9341_COLOR_BLACK);

		HAL_Delay(4000);
		TM_ILI9341_Fill(ILI9341_COLOR_BLACK);
	}

	void TM_ILI9341_MPX_plot(uint32_t frec_index, float32_t max){

		uint16_t i;
		static uint16_t posicion_ventana_anterior = 0;
		static uint16_t posicion_ventana_actual = RANGO_FULL_SPAN;
		static int freq_old = 0, freq =0;
		static float amp = 0, amp_old = 0;
		static uint8_t tipo_ventana = RECTANGULAR;
		osEvent evt_window;
		osEvent evt_span;

		evt_span = osMessageGet(QueueSpanHandle, 0);
		if(evt_span.status == osEventMessage)
			posicion_ventana_actual = (uint16_t) evt_span.value.v;

		evt_window = osMessageGet(QueueWindowHandle, 0);
		if(evt_window.status == osEventMessage){
			tipo_ventana = (uint8_t) evt_window.value.v;
			Nombre_ventana_pantalla(tipo_ventana);
		}

		if (posicion_ventana_actual != posicion_ventana_anterior){
			//Borro Toda la pantalla
			TM_ILI9341_Fill(ILI9341_COLOR_BLACK);

			//Redibujo los ejes XY
			TM_ILI9341_MPX_axis();
			TM_ILI9341_MPX_axis_setup(posicion_ventana_actual);
			Nombre_ventana_pantalla(tipo_ventana);
			mostrar_frecuencia(freq);
			mostrar_amplitud(amp);

			posicion_ventana_anterior = posicion_ventana_actual;
		}




		for (i=1; i<SCREEN_WIDTH; i++){

			if ( posicion_ventana_actual == RANGO_FULL_SPAN && i<256)
			{
				Escribir_Pixel_x ( i + FFT_OFFSET_X , (uint16_t) (SCREEN_HEIGHT -  FFT_OFFSET_Y - 4.6* (transformada_final_anterior[4*i])  ) , ILI9341_COLOR_BLACK);
				Escribir_Pixel_x ( i + FFT_OFFSET_X , (uint16_t) (SCREEN_HEIGHT -  FFT_OFFSET_Y - 4.6* (transformada_final[4*i]) ) , ILI9341_COLOR_CYAN);

			}

			else if ( i + posicion_ventana_actual < 1024 )
			{
				Escribir_Pixel_x ( i + FFT_OFFSET_X , (uint16_t) (SCREEN_HEIGHT -  FFT_OFFSET_Y - 4.6* (transformada_final_anterior[i + posicion_ventana_actual]) ) , ILI9341_COLOR_BLACK);
				Escribir_Pixel_x ( i + FFT_OFFSET_X , (uint16_t) (SCREEN_HEIGHT -  FFT_OFFSET_Y - 4.6* (transformada_final[i + posicion_ventana_actual]) ) , ILI9341_COLOR_CYAN);
			}
		}


		//Imprimo la frecuencia en pantalla
		freq = (int)(frec_index*FREQUENCY_SCALE);
		if(freq_old != freq){
			mostrar_frecuencia(freq);
			freq_old = freq;
		}

		amp = (int)(max*AMPLITUD_SCALE);
		if(amp_old != amp){
			mostrar_amplitud(amp);
			amp_old = amp;
		}

		if (posicion_ventana_actual == RANGO_FULL_SPAN)
				TM_ILI9341_Puts(230,14, "Full Span", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);

	}








	void mostrar_frecuencia(uint32_t freq){
		static char freq_str[5];

		TM_ILI9341_Puts(87, 2, freq_str , &TM_Font_7x10, ILI9341_COLOR_BLACK, ILI9341_COLOR_BLACK);
		itoa(freq, freq_str, 10);
		TM_ILI9341_Puts(FREQ_SHOW_BEGIN_X ,2, "(" , &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts(FREQ_SHOW_BEGIN_NUM_X, 2, freq_str , &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts(FREQ_SHOW_UNITS_POS_X, 2, "+-15)Hz" , &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
	}

	void mostrar_amplitud(uint32_t amp){
			static char amp_str[3];

			TM_ILI9341_Puts(AMP_SHOW_BEGIN_X, 12, amp_str , &TM_Font_7x10, ILI9341_COLOR_BLACK, ILI9341_COLOR_BLACK);
			itoa(amp, amp_str, 10);
			TM_ILI9341_Puts(AMP_SHOW_BEGIN_X, 12, amp_str , &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
			TM_ILI9341_Puts(AMP_SHOW_MV_POS_X, 12, "mV" , &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		}


	void TM_ILI9341_MPX_axis(void){

		TM_ILI9341_DrawLine(FFT_OFFSET_X-1 ,1 ,FFT_OFFSET_X -1,SCREEN_HEIGHT-FFT_OFFSET_Y , ILI9341_COLOR_WHITE);
		TM_ILI9341_DrawLine(FFT_OFFSET_X-1, SCREEN_HEIGHT-FFT_OFFSET_Y+1, SCREEN_WIDTH, SCREEN_HEIGHT-FFT_OFFSET_Y+1, ILI9341_COLOR_WHITE);

		TM_ILI9341_MPX_x_axis_mark((SCREEN_WIDTH-FFT_OFFSET_X)/2 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark((SCREEN_WIDTH-FFT_OFFSET_X)/4 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark((SCREEN_WIDTH-FFT_OFFSET_X)*3/4 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark((SCREEN_WIDTH-FFT_OFFSET_X)/8 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark((SCREEN_WIDTH-FFT_OFFSET_X)*3/8 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark((SCREEN_WIDTH-FFT_OFFSET_X)*5/8 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark((SCREEN_WIDTH-FFT_OFFSET_X)*7/8 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark(SCREEN_WIDTH-1);

		TM_ILI9341_MPX_y_axis_mark(0);
		TM_ILI9341_MPX_y_axis_mark((SCREEN_HEIGHT-FFT_OFFSET_Y)/4);
		TM_ILI9341_MPX_y_axis_mark((SCREEN_HEIGHT-FFT_OFFSET_Y)/2);
		TM_ILI9341_MPX_y_axis_mark((SCREEN_HEIGHT-FFT_OFFSET_Y)*3/4);

		//TM_ILI9341_Puts(FFT_OFFSET_X-10,SCREEN_HEIGHT-FFT_OFFSET_Y+10, "0", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);

		TM_ILI9341_Puts(0,0, "500mV", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts(0,(SCREEN_HEIGHT-FFT_OFFSET_Y)/4-5, "375mV", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts(0,(SCREEN_HEIGHT-FFT_OFFSET_Y)/2-5, "250mV", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts(0,(SCREEN_HEIGHT-FFT_OFFSET_Y)*3/4-5, "125mV", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts(FFT_OFFSET_X-28,SCREEN_HEIGHT-FFT_OFFSET_Y-10, "0mV", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);

	}

	void TM_ILI9341_MPX_x_axis_mark(uint16_t pos){

		TM_ILI9341_DrawLine(pos ,SCREEN_HEIGHT-FFT_OFFSET_Y ,pos ,SCREEN_HEIGHT-FFT_OFFSET_Y+5 , ILI9341_COLOR_WHITE);

		//Para calibracion descomentar, y comentar el de arriba
		//TM_ILI9341_DrawLine(pos ,1 ,pos ,SCREEN_HEIGHT-FFT_OFFSET_Y+5 , ILI9341_COLOR_WHITE);

	}

	void TM_ILI9341_MPX_x_axis_mark_DELETE(uint16_t pos){

		TM_ILI9341_DrawLine(pos ,SCREEN_HEIGHT-FFT_OFFSET_Y ,pos ,SCREEN_HEIGHT-FFT_OFFSET_Y+5 , ILI9341_COLOR_BLACK);

		//Para calibracion descomentar, y comentar el de arriba
		//TM_ILI9341_DrawLine(pos ,1 ,pos ,SCREEN_HEIGHT-FFT_OFFSET_Y+5 , ILI9341_COLOR_BLACK);

	}



	void TM_ILI9341_MPX_y_axis_mark(uint16_t pos){

			TM_ILI9341_DrawLine(FFT_OFFSET_X-5 ,pos ,FFT_OFFSET_X+5, pos , ILI9341_COLOR_WHITE);

			//Para calibraci�n descomentar abajo
			//TM_ILI9341_DrawLine(FFT_OFFSET_X-5 ,pos ,SCREEN_WIDTH, pos , ILI9341_COLOR_WHITE);


		}






void Escribir_Pixel_x (uint16_t x, uint16_t y, uint16_t color)
	{

		TM_ILI9341_DrawPixel(x,y,color);

		if (x >0)
			TM_ILI9341_DrawPixel(x-1,y,color);


		if (x < 319)
			TM_ILI9341_DrawPixel(x+1,y,color);


		if (y >0)
			TM_ILI9341_DrawPixel(x,y-1,color);


		if (y < 219)
			TM_ILI9341_DrawPixel(x,y+1,color);

	}




void TM_ILI9341_MPX_axis_setup (uint16_t escala_x){


switch ( escala_x ){
	case RANGO_0_290:
		TM_ILI9341_Puts(FFT_OFFSET_X,SCREEN_HEIGHT-FFT_OFFSET_Y+10, "0k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((SCREEN_WIDTH-FFT_OFFSET_X)/4 + FFT_OFFSET_X -15, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "1.12k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((SCREEN_WIDTH-FFT_OFFSET_X)/2 + FFT_OFFSET_X -10, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "2.24k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((SCREEN_WIDTH-FFT_OFFSET_X)*3/4 + FFT_OFFSET_X -20, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "3.36k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts(SCREEN_WIDTH - 35, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "4.48k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		break;
	case RANGO_291_580:
		TM_ILI9341_Puts(FFT_OFFSET_X-10, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "4.48k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((SCREEN_WIDTH-FFT_OFFSET_X)/4 + FFT_OFFSET_X -15, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "5.60k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((SCREEN_WIDTH-FFT_OFFSET_X)/2 + FFT_OFFSET_X -15, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "6.72k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((SCREEN_WIDTH-FFT_OFFSET_X)*3/4 + FFT_OFFSET_X -20, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "7.84k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts(SCREEN_WIDTH - 35, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "8.96k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		break;
	case RANGO_581_870:
		TM_ILI9341_Puts(FFT_OFFSET_X-10,SCREEN_HEIGHT-FFT_OFFSET_Y+10, "8.96k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((SCREEN_WIDTH-FFT_OFFSET_X)/4 + FFT_OFFSET_X -20, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "10.07k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((SCREEN_WIDTH-FFT_OFFSET_X)/2 + FFT_OFFSET_X -20, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "11.19k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((SCREEN_WIDTH-FFT_OFFSET_X)*3/4 + FFT_OFFSET_X -20, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "12.31k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts(SCREEN_WIDTH - 35, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "13.4k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);

		break;
	case RANGO_871_1160:
		TM_ILI9341_Puts(FFT_OFFSET_X-10,SCREEN_HEIGHT-FFT_OFFSET_Y+10, "13.4k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((SCREEN_WIDTH-FFT_OFFSET_X)/4 + FFT_OFFSET_X -20, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "14.55k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((SCREEN_WIDTH-FFT_OFFSET_X)/2 + FFT_OFFSET_X -20, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "15.67k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((SCREEN_WIDTH-FFT_OFFSET_X)*3/4 + FFT_OFFSET_X -20, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "16.8k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts(SCREEN_WIDTH - 35, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "18.0k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);

		break;

	case RANGO_FULL_SPAN:

		TM_ILI9341_MPX_x_axis_mark_DELETE((SCREEN_WIDTH-FFT_OFFSET_X)/2 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark_DELETE((SCREEN_WIDTH-FFT_OFFSET_X)/4 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark_DELETE((SCREEN_WIDTH-FFT_OFFSET_X)*3/4 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark_DELETE((SCREEN_WIDTH-FFT_OFFSET_X)/8 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark_DELETE((SCREEN_WIDTH-FFT_OFFSET_X)*3/8 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark_DELETE((SCREEN_WIDTH-FFT_OFFSET_X)*5/8 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark_DELETE((SCREEN_WIDTH-FFT_OFFSET_X)*7/8 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark_DELETE(SCREEN_WIDTH-4);

		TM_ILI9341_MPX_x_axis_mark((256)/2   + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark((256)/4   + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark((256)*3/4 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark((256)/8   + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark((256)*3/8 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark((256)*5/8 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark((256)*7/8 + FFT_OFFSET_X);
		TM_ILI9341_MPX_x_axis_mark((256)	 + FFT_OFFSET_X);

		TM_ILI9341_MPX_x_axis_mark(SCREEN_WIDTH-4);

		TM_ILI9341_Puts(FFT_OFFSET_X,SCREEN_HEIGHT-FFT_OFFSET_Y+10, "0k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((256)/4 + FFT_OFFSET_X -5 , SCREEN_HEIGHT-FFT_OFFSET_Y+10, "4k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((256)/2 + FFT_OFFSET_X -5, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "8k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts((256)*3/4 + FFT_OFFSET_X -15, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "12k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
		TM_ILI9341_Puts(256 + FFT_OFFSET_X -12, SCREEN_HEIGHT-FFT_OFFSET_Y+10, "16k", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);

		break;

	}
}


void Nombre_ventana_pantalla (uint16_t nombre)
{

	TM_ILI9341_Puts(230,2, "Rectangular", &TM_Font_7x10, ILI9341_COLOR_BLACK, ILI9341_COLOR_BLACK);

	switch (nombre){
		case RECTANGULAR:
			TM_ILI9341_Puts(230,2, "Rectangular", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
			break;
		case HAMMING:
			TM_ILI9341_Puts(230,2, "Hamming", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
			break;
		case BLACKMAN:
			TM_ILI9341_Puts(230,2, "Blackman", &TM_Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
			break;
	}
}

