/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2018 STMicroelectronics International N.V. 
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"

/* USER CODE BEGIN Includes */     
#include "mpx.h"
#include "Display_TM_ILI9341.h"
#include "header.h"

/* USER CODE END Includes */

/* Variables -----------------------------------------------------------------*/
osThreadId defaultTaskHandle;
osThreadId I2SReadHandle;
osThreadId TecladoReadHandle;
osThreadId TecladoResolveHandle;
osMessageQId QueueKeyHandle;
osMessageQId QueueWindowHandle;
osMessageQId QueueSpanHandle;
osSemaphoreId SemI2SReadHandle;
osSemaphoreId SemReadKeyHandle;

/* USER CODE BEGIN Variables */

/* USER CODE END Variables */

/* Function prototypes -------------------------------------------------------*/
void StartDefaultTask(void const * argument);
void vTask_I2SRead(void const * argument);
void vTask_TecladoRead(void const * argument);
void vTask_TecladoResolve(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* USER CODE BEGIN FunctionPrototypes */
/* USER CODE END FunctionPrototypes */

/* Hook prototypes */

/* Init FreeRTOS */

void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */


  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* definition and creation of SemI2SRead */
  osSemaphoreDef(SemI2SRead);
  SemI2SReadHandle = osSemaphoreCreate(osSemaphore(SemI2SRead), 1);

  /* definition and creation of SemReadKey */
  osSemaphoreDef(SemReadKey);
  SemReadKeyHandle = osSemaphoreCreate(osSemaphore(SemReadKey), 1);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* definition and creation of I2SRead */
  osThreadDef(I2SRead, vTask_I2SRead, osPriorityNormal, 0, 128);
  I2SReadHandle = osThreadCreate(osThread(I2SRead), NULL);

  /* definition and creation of TecladoRead */
  osThreadDef(TecladoRead, vTask_TecladoRead, osPriorityAboveNormal, 0, 128);
  TecladoReadHandle = osThreadCreate(osThread(TecladoRead), NULL);

  /* definition and creation of TecladoResolve */
  osThreadDef(TecladoResolve, vTask_TecladoResolve, osPriorityHigh, 0, 128);
  TecladoResolveHandle = osThreadCreate(osThread(TecladoResolve), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* USER CODE END RTOS_THREADS */

  /* Create the queue(s) */
  /* definition and creation of QueueKey */
  osMessageQDef(QueueKey, 1, uint8_t);
  QueueKeyHandle = osMessageCreate(osMessageQ(QueueKey), 0);

  /* definition and creation of QueueWindow */
  osMessageQDef(QueueWindow, 1, uint8_t);
  QueueWindowHandle = osMessageCreate(osMessageQ(QueueWindow), 0);

  /* definition and creation of QueueSpan */
  osMessageQDef(QueueSpan, 1, uint16_t);
  QueueSpanHandle = osMessageCreate(osMessageQ(QueueSpan), 0);

  /* USER CODE BEGIN RTOS_QUEUES */

  /* USER CODE END RTOS_QUEUES */
}

/* StartDefaultTask function */
void StartDefaultTask(void const * argument)
{

  /* USER CODE BEGIN StartDefaultTask */

	/* Infinite loop */
	for(;;) {

	}
  /* USER CODE END StartDefaultTask */
}

/* vTask_I2SRead function */
void vTask_I2SRead(void const * argument)
{
  /* USER CODE BEGIN vTask_I2SRead */
	/* Infinite loop */
	while(1){

		osSemaphoreWait(SemI2SReadHandle,portMAX_DELAY);

		led_ok();

		if(transmit_ready == HAL_OK){

			//Leer_teclado ();

			I2S_Read();

			mpx_loop();

			TM_ILI9341_MPX_plot();

			osSemaphoreRelease(SemReadKeyHandle);

		}

	}
  /* USER CODE END vTask_I2SRead */
}

/* vTask_TecladoRead function */
void vTask_TecladoRead(void const * argument)
{
  /* USER CODE BEGIN vTask_TecladoRead */
	osSemaphoreWait(SemReadKeyHandle, portMAX_DELAY);
  /* Infinite loop */
  for(;;)
  {
	  osSemaphoreWait(SemReadKeyHandle, portMAX_DELAY);
	  Leer_teclado ();
	  osSemaphoreRelease(SemI2SReadHandle);
  }
  /* USER CODE END vTask_TecladoRead */
}

/* vTask_TecladoResolve function */
void vTask_TecladoResolve(void const * argument)
{
  /* USER CODE BEGIN vTask_TecladoResolve */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END vTask_TecladoResolve */
}

/* USER CODE BEGIN Application */

     
/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
