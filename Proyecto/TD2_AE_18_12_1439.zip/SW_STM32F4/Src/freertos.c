/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2018 STMicroelectronics International N.V. 
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"

/* USER CODE BEGIN Includes */     
#include "mpx.h"
#include "Display_TM_ILI9341.h"
#include "header.h"

/* USER CODE END Includes */

/* Variables -----------------------------------------------------------------*/


osThreadId defaultTaskHandle;
osThreadId I2SReadHandle;
osThreadId SigProcHandle;
osThreadId PlotHandle;
osSemaphoreId SemReadHandle;
osSemaphoreId SemProcHandle;
osSemaphoreId SemPlotHandle;

/* USER CODE BEGIN Variables */
//extern	float32_t transformada_final[MUESTRAS/2];
//
//extern	float32_t transformada_final_anterior[MUESTRAS/2];
//
//extern	float32_t *buffer_rx_left;
//
//extern	float32_t *buffer_rx_right;

uint16_t posicion_ventana = RANGO_FULL_SPAN;

uint16_t tipo_ventana = RECTANGULAR;

uint8_t tecla;

float32_t buffer_suma[LEN_TX_RX];
float32_t transformada [MUESTRAS];
float32_t transformada_final[MUESTRAS/2];
float32_t transformada_final_anterior[MUESTRAS/2];

	arm_rfft_fast_instance_f32 sint;
/* USER CODE END Variables */

/* Function prototypes -------------------------------------------------------*/
void StartDefaultTask(void const * argument);
void vTask_I2SRead(void const * argument);
void vTask_SigProc(void const * argument);
void vTask_Plot(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* USER CODE BEGIN FunctionPrototypes */
/* USER CODE END FunctionPrototypes */

/* Hook prototypes */

/* Init FreeRTOS */

void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */


  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* definition and creation of SemRead */
  osSemaphoreDef(SemRead);
  SemReadHandle = osSemaphoreCreate(osSemaphore(SemRead), 1);

  /* definition and creation of SemProc */
  osSemaphoreDef(SemProc);
  SemProcHandle = osSemaphoreCreate(osSemaphore(SemProc), 1);

  /* definition and creation of SemPlot */
  osSemaphoreDef(SemPlot);
  SemPlotHandle = osSemaphoreCreate(osSemaphore(SemPlot), 1);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* definition and creation of I2SRead */
  osThreadDef(I2SRead, vTask_I2SRead, 0, 0, 128);
  I2SReadHandle = osThreadCreate(osThread(I2SRead), NULL);

  /* definition and creation of SigProc */
//  osThreadDef(SigProc, vTask_SigProc, osPriorityBelowNormal, 0, 128);
//  SigProcHandle = osThreadCreate(osThread(SigProc), NULL);

  /* definition and creation of Plot */
//  osThreadDef(Plot, vTask_Plot, osPriorityNormal+1, 0, 128);
//  PlotHandle = osThreadCreate(osThread(Plot), NULL);

  /* definition and creation of LeerTeclado */
//  osThreadDef(LeerTeclado, vTask_LeerTeclado, 0, 0, 128);
//  LeerTecladoHandle = osThreadCreate(osThread(LeerTeclado), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */
}

/* StartDefaultTask function */
void StartDefaultTask(void const * argument)
{

  /* USER CODE BEGIN StartDefaultTask */

	/* Infinite loop */
	for(;;) {

	}
  /* USER CODE END StartDefaultTask */
}

/* vTask_I2SRead function */
void vTask_I2SRead(void const * argument)
{
  /* USER CODE BEGIN vTask_I2SRead */

	//xSemaphoreTake(SemReadHandle,portMAX_DELAY);

	/* Infinite loop */
	while(1){

		//xSemaphoreTake(SemReadHandle,portMAX_DELAY);

		led_ok();

		// Menu calibracion
		if(transmit_ready == HAL_OK){

			Leer_teclado ();

			I2S_Read();

			mpx_loop();

			TM_ILI9341_MPX_plot();

		}

	}
  /* USER CODE END vTask_I2SRead */
}

/* vTask_SigProc function */
void vTask_SigProc(void const * argument)
{
  /* USER CODE BEGIN vTask_SigProc */

	//xSemaphoreTake(SemProcHandle,portMAX_DELAY);

	/* Infinite loop */

	for(;;){
		xSemaphoreTake(SemProcHandle,portMAX_DELAY);

		mpx_loop();
		xSemaphoreGive(SemPlotHandle);

	}
  /* USER CODE END vTask_SigProc */
}

/* vTask_Plot function */
void vTask_Plot(void const * argument)
{
  /* USER CODE BEGIN vTask_Plot */

	xSemaphoreTake(SemPlotHandle,portMAX_DELAY);

	/* Infinite loop */

	for(;;){

		xSemaphoreTake(SemPlotHandle,portMAX_DELAY);
		TM_ILI9341_MPX_plot();

		xSemaphoreGive(SemReadHandle);


	}
  /* USER CODE END vTask_Plot */
}





/* USER CODE BEGIN Application */

     
/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
