/*
 * Botonera.c
 *
 *  Created on: 19 dic. 2018
 *      Author: Andres Hojnadel
 */


#include "gpio.h"
#include "cmsis_os.h"
#include "Botonera.h"
#include "Display_TM_ILI9341.h"


/* Variables globales y esternas*/
extern osMessageQId QueueWindowHandle;
extern osMessageQId QueueSpanHandle;
osMessageQId QueueKeyHandle;




void Leer_teclado (void){

	if 		( !HAL_GPIO_ReadPin(SW2_GPIO_Port,SW2_Pin) )
		osMessagePut(QueueKeyHandle, SW1, 0);
	else if ( !HAL_GPIO_ReadPin(SW1_GPIO_Port,SW1_Pin) )
		osMessagePut(QueueKeyHandle, SW2, 0);
	else if ( !HAL_GPIO_ReadPin(SW3_GPIO_Port,SW3_Pin) )
		osMessagePut(QueueKeyHandle, SW3, 0);
	else if ( !HAL_GPIO_ReadPin(SW4_GPIO_Port,SW4_Pin) )
		osMessagePut(QueueKeyHandle, SW4, 0);

}

void Hacer_Teclado(uint8_t tecla){

	static uint8_t ventana = RECTANGULAR;
	static uint16_t span = RANGO_FULL_SPAN;

	switch (tecla){
			case SW1:
				span = span + ANCHO_SPAN;
				if (span == RANGO_FULL_SPAN +ANCHO_SPAN)
					span = 0;
				osMessagePut(QueueSpanHandle, span, 0);
				osMessagePut(QueueWindowHandle, ventana, 0);
				break;

			case SW2:
				ventana++;
				if (ventana == 3)
					ventana = 0;

				osMessagePut(QueueWindowHandle, ventana, 0);
				break;

			case SW3:
				if (span == RANGO_0_290)
					span = RANGO_FULL_SPAN;
				else
					span = span - ANCHO_SPAN;
				osMessagePut(QueueSpanHandle, span, 0);
				osMessagePut(QueueWindowHandle, ventana, 0);
				break;

			case SW4:
				span = RANGO_FULL_SPAN;
				osMessagePut(QueueSpanHandle, RANGO_FULL_SPAN, 0);
				osMessagePut(QueueWindowHandle, ventana, 0);
				break;
		}//End Switch
		tecla = NO_KEY;
}
