/*
 * led.h
 *
 *  Created on: 20 mar. 2018
 *      Author: alumno
 */

#ifndef INC_LED_H_
#define INC_LED_H_











/*****************************************************************************************************
 * 											FUNCIONES
 *****************************************************************************************************/
	/**
	  * @brief 	Led everthing-is-fine
	  * @param  None
	  * @retval None
	  */
	void led_ok();








#endif /* INC_LED_H_ */
